﻿namespace TP2_APP_Reduction
{
    partial class Reduction
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_machat = new System.Windows.Forms.TextBox();
            this.txt_taux = new System.Windows.Forms.TextBox();
            this.txt_mapayer = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.calculer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(70, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(199, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Saisir le montant de l\'achat";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(70, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 20);
            this.label2.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(70, 175);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Montant à payer";
            // 
            // txt_machat
            // 
            this.txt_machat.Location = new System.Drawing.Point(304, 50);
            this.txt_machat.Name = "txt_machat";
            this.txt_machat.Size = new System.Drawing.Size(219, 26);
            this.txt_machat.TabIndex = 3;
            this.txt_machat.Text = "0";
            // 
            // txt_taux
            // 
            this.txt_taux.Location = new System.Drawing.Point(304, 117);
            this.txt_taux.Name = "txt_taux";
            this.txt_taux.Size = new System.Drawing.Size(219, 26);
            this.txt_taux.TabIndex = 4;
            this.txt_taux.Text = "0";
            // 
            // txt_mapayer
            // 
            this.txt_mapayer.Location = new System.Drawing.Point(304, 187);
            this.txt_mapayer.Name = "txt_mapayer";
            this.txt_mapayer.Size = new System.Drawing.Size(219, 26);
            this.txt_mapayer.TabIndex = 5;
            this.txt_mapayer.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(70, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(142, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Taux de Réduction";
            // 
            // calculer
            // 
            this.calculer.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.calculer.Location = new System.Drawing.Point(372, 261);
            this.calculer.Name = "calculer";
            this.calculer.Size = new System.Drawing.Size(151, 44);
            this.calculer.TabIndex = 7;
            this.calculer.Text = "Calculer";
            this.calculer.UseVisualStyleBackColor = false;
            this.calculer.Click += new System.EventHandler(this.calculer_Click);
            // 
            // Reduction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.calculer);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_mapayer);
            this.Controls.Add(this.txt_taux);
            this.Controls.Add(this.txt_machat);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Reduction";
            this.Text = "Reduction";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_machat;
        private System.Windows.Forms.TextBox txt_taux;
        private System.Windows.Forms.TextBox txt_mapayer;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button calculer;
    }
}

