﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP2_APP_Reduction
{
    public partial class Reduction : Form
    {
        public Reduction()
        {
            InitializeComponent();
        }



        private void calculer_Click(object sender, EventArgs e)
        {
            double machat = double.Parse(txt_machat.Text);
            double taux = 0;
            double maPayer = 0;
            double pourcentage = 0;
            if (machat > 5000)
            {
                taux = 0.2;
            }
            else if (machat > 4000)
            {
                taux = 0.15;
            }
            else if (machat > 3000)
            {
                taux = 0.1;
            }
            else if (machat > 1000)
            {
                taux = 0.05;
            }
            maPayer = machat - machat * taux;
            pourcentage = taux * 100;
            txt_taux.Text = pourcentage + "%";
            txt_mapayer.Text = maPayer.ToString();

        }
    }
}
