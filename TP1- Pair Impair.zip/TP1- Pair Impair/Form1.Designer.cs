﻿namespace TP1__Pair_Impair
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.Nombre = new System.Windows.Forms.Label();
            this.Tester = new System.Windows.Forms.Button();
            this.textBoxNombre = new System.Windows.Forms.TextBox();
            this.labAfficher = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Nombre
            // 
            this.Nombre.AutoSize = true;
            this.Nombre.Location = new System.Drawing.Point(67, 50);
            this.Nombre.Name = "Nombre";
            this.Nombre.Size = new System.Drawing.Size(65, 20);
            this.Nombre.TabIndex = 0;
            this.Nombre.Text = "Nombre";
            // 
            // Tester
            // 
            this.Tester.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Tester.Location = new System.Drawing.Point(586, 50);
            this.Tester.Name = "Tester";
            this.Tester.Size = new System.Drawing.Size(157, 31);
            this.Tester.TabIndex = 1;
            this.Tester.Text = "Tester";
            this.Tester.UseVisualStyleBackColor = false;
            this.Tester.Click += new System.EventHandler(this.Tester_Click);
            // 
            // textBoxNombre
            // 
            this.textBoxNombre.Location = new System.Drawing.Point(195, 50);
            this.textBoxNombre.Name = "textBoxNombre";
            this.textBoxNombre.Size = new System.Drawing.Size(349, 26);
            this.textBoxNombre.TabIndex = 2;
            // 
            // labAfficher
            // 
            this.labAfficher.AutoSize = true;
            this.labAfficher.Location = new System.Drawing.Point(214, 137);
            this.labAfficher.Name = "labAfficher";
            this.labAfficher.Size = new System.Drawing.Size(0, 20);
            this.labAfficher.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labAfficher);
            this.Controls.Add(this.textBoxNombre);
            this.Controls.Add(this.Tester);
            this.Controls.Add(this.Nombre);
            this.Name = "Form1";
            this.Text = "PairImpair";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Nombre;
        private System.Windows.Forms.Button Tester;
        private System.Windows.Forms.TextBox textBoxNombre;
        private System.Windows.Forms.Label labAfficher;
    }
}

