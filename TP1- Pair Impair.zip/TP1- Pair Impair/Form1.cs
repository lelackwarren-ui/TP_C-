﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1__Pair_Impair
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Tester_Click(object sender, EventArgs e)
        {
            int nombre = int.Parse(textBoxNombre.Text);
            string msg = " ";
            if (nombre % 2 == 0)
            {
                msg = "Le nombre " + nombre + " est pair.";
            }
            else
            {
                msg = "Le nombre " + nombre + " est impair.";
            }
            labAfficher.Text = msg;
        }
    }
}
