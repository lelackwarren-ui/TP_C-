﻿namespace TP1_APP
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_pre = new System.Windows.Forms.Label();
            this.txt_nom = new System.Windows.Forms.Label();
            this.preBox = new System.Windows.Forms.TextBox();
            this.NomBox = new System.Windows.Forms.TextBox();
            this.btn_aff = new System.Windows.Forms.Button();
            this.message = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_pre
            // 
            this.txt_pre.AutoSize = true;
            this.txt_pre.Location = new System.Drawing.Point(94, 44);
            this.txt_pre.Name = "txt_pre";
            this.txt_pre.Size = new System.Drawing.Size(72, 20);
            this.txt_pre.TabIndex = 0;
            this.txt_pre.Text = "Prénoms";
            // 
            // txt_nom
            // 
            this.txt_nom.AutoSize = true;
            this.txt_nom.Location = new System.Drawing.Point(94, 101);
            this.txt_nom.Name = "txt_nom";
            this.txt_nom.Size = new System.Drawing.Size(42, 20);
            this.txt_nom.TabIndex = 1;
            this.txt_nom.Text = "Nom";
            // 
            // preBox
            // 
            this.preBox.Location = new System.Drawing.Point(230, 44);
            this.preBox.Name = "preBox";
            this.preBox.Size = new System.Drawing.Size(290, 26);
            this.preBox.TabIndex = 2;
            // 
            // NomBox
            // 
            this.NomBox.Location = new System.Drawing.Point(230, 101);
            this.NomBox.Name = "NomBox";
            this.NomBox.Size = new System.Drawing.Size(290, 26);
            this.NomBox.TabIndex = 3;
            // 
            // btn_aff
            // 
            this.btn_aff.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_aff.Location = new System.Drawing.Point(404, 171);
            this.btn_aff.Name = "btn_aff";
            this.btn_aff.Size = new System.Drawing.Size(116, 35);
            this.btn_aff.TabIndex = 4;
            this.btn_aff.Text = "Afficher";
            this.btn_aff.UseVisualStyleBackColor = false;
            this.btn_aff.Click += new System.EventHandler(this.btn_aff_Click);
            // 
            // message
            // 
            this.message.AutoSize = true;
            this.message.Location = new System.Drawing.Point(39, 238);
            this.message.Name = "message";
            this.message.Size = new System.Drawing.Size(0, 20);
            this.message.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.message);
            this.Controls.Add(this.btn_aff);
            this.Controls.Add(this.NomBox);
            this.Controls.Add(this.preBox);
            this.Controls.Add(this.txt_nom);
            this.Controls.Add(this.txt_pre);
            this.Name = "Form1";
            this.Text = "AfficherNom";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txt_pre;
        private System.Windows.Forms.Label txt_nom;
        private System.Windows.Forms.TextBox preBox;
        private System.Windows.Forms.TextBox NomBox;
        private System.Windows.Forms.Button btn_aff;
        private System.Windows.Forms.Label message;
    }
}

