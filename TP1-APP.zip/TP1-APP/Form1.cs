﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1_APP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_aff_Click(object sender, EventArgs e)
        {
            message.Text = "Bonjour : " + preBox.Text + " " +  NomBox.Text;
        }
    }
}
