﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP2_CalculatriceAPP
{
    public partial class Calculatrice : Form
    {
        public Calculatrice()
        {
            InitializeComponent();
        }

        private void Calculer_Click(object sender, EventArgs e)
        {
            int nbr1 = int.Parse(txt_nbr1.Text);
            int nbr2 = int.Parse(txt_nbr2.Text);
            if (rb_add.Checked)
            {
                int sum = nbr1 + nbr2;
                txt_resultat.Text = sum.ToString();
            }
            else if (rb_sous.Checked)  
            {
                int sous = nbr1 - nbr2;
                txt_resultat.Text = sous.ToString();
            }
            else if (rb_mu.Checked)
            {
                int multi = nbr1 * nbr2;
                txt_resultat.Text = multi.ToString();
            }
            else if (rb_div.Checked)
            {
                double div = nbr1 / nbr2;
                txt_resultat.Text = div.ToString();
            }
            else
            {
                MessageBox.Show("Aucune opération est séléctionnée!!", "Erreur");
            }
        }

        private void Quitter_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


    }
}
