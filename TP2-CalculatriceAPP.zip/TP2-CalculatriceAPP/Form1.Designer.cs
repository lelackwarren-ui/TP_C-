﻿namespace TP2_CalculatriceAPP
{
    partial class Calculatrice
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Calculatrice));
            this.Nbr1 = new System.Windows.Forms.Label();
            this.Nbr2 = new System.Windows.Forms.Label();
            this.resultat = new System.Windows.Forms.Label();
            this.txt_nbr1 = new System.Windows.Forms.TextBox();
            this.txt_nbr2 = new System.Windows.Forms.TextBox();
            this.txt_resultat = new System.Windows.Forms.TextBox();
            this.OperationBox = new System.Windows.Forms.GroupBox();
            this.rb_div = new System.Windows.Forms.RadioButton();
            this.rb_mu = new System.Windows.Forms.RadioButton();
            this.rb_sous = new System.Windows.Forms.RadioButton();
            this.rb_add = new System.Windows.Forms.RadioButton();
            this.Calculer = new System.Windows.Forms.Button();
            this.Quitter = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.OperationBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // Nbr1
            // 
            this.Nbr1.AutoSize = true;
            this.Nbr1.Location = new System.Drawing.Point(68, 32);
            this.Nbr1.Name = "Nbr1";
            this.Nbr1.Size = new System.Drawing.Size(78, 20);
            this.Nbr1.TabIndex = 0;
            this.Nbr1.Text = "Nombre 1";
            // 
            // Nbr2
            // 
            this.Nbr2.AutoSize = true;
            this.Nbr2.Location = new System.Drawing.Point(68, 98);
            this.Nbr2.Name = "Nbr2";
            this.Nbr2.Size = new System.Drawing.Size(78, 20);
            this.Nbr2.TabIndex = 1;
            this.Nbr2.Text = "Nombre 2";
            // 
            // resultat
            // 
            this.resultat.AutoSize = true;
            this.resultat.Location = new System.Drawing.Point(68, 150);
            this.resultat.Name = "resultat";
            this.resultat.Size = new System.Drawing.Size(69, 20);
            this.resultat.TabIndex = 2;
            this.resultat.Text = "Résultat";
            // 
            // txt_nbr1
            // 
            this.txt_nbr1.Location = new System.Drawing.Point(204, 42);
            this.txt_nbr1.Name = "txt_nbr1";
            this.txt_nbr1.Size = new System.Drawing.Size(206, 26);
            this.txt_nbr1.TabIndex = 3;
            this.txt_nbr1.Text = "0";
            // 
            // txt_nbr2
            // 
            this.txt_nbr2.Location = new System.Drawing.Point(204, 98);
            this.txt_nbr2.Name = "txt_nbr2";
            this.txt_nbr2.Size = new System.Drawing.Size(206, 26);
            this.txt_nbr2.TabIndex = 4;
            this.txt_nbr2.Text = "0";
            // 
            // txt_resultat
            // 
            this.txt_resultat.Location = new System.Drawing.Point(204, 150);
            this.txt_resultat.Name = "txt_resultat";
            this.txt_resultat.Size = new System.Drawing.Size(206, 26);
            this.txt_resultat.TabIndex = 5;
            this.txt_resultat.Text = "0";
            // 
            // OperationBox
            // 
            this.OperationBox.Controls.Add(this.rb_div);
            this.OperationBox.Controls.Add(this.rb_mu);
            this.OperationBox.Controls.Add(this.rb_sous);
            this.OperationBox.Controls.Add(this.rb_add);
            this.OperationBox.Location = new System.Drawing.Point(106, 209);
            this.OperationBox.Name = "OperationBox";
            this.OperationBox.Size = new System.Drawing.Size(330, 201);
            this.OperationBox.TabIndex = 6;
            this.OperationBox.TabStop = false;
            this.OperationBox.Text = "Operation";
            // 
            // rb_div
            // 
            this.rb_div.AutoSize = true;
            this.rb_div.Location = new System.Drawing.Point(24, 135);
            this.rb_div.Name = "rb_div";
            this.rb_div.Size = new System.Drawing.Size(88, 24);
            this.rb_div.TabIndex = 3;
            this.rb_div.TabStop = true;
            this.rb_div.Text = "Division";
            this.rb_div.UseVisualStyleBackColor = true;
            // 
            // rb_mu
            // 
            this.rb_mu.AutoSize = true;
            this.rb_mu.Location = new System.Drawing.Point(24, 105);
            this.rb_mu.Name = "rb_mu";
            this.rb_mu.Size = new System.Drawing.Size(125, 24);
            this.rb_mu.TabIndex = 2;
            this.rb_mu.TabStop = true;
            this.rb_mu.Text = "Multiplication";
            this.rb_mu.UseVisualStyleBackColor = true;
            // 
            // rb_sous
            // 
            this.rb_sous.AutoSize = true;
            this.rb_sous.Location = new System.Drawing.Point(24, 75);
            this.rb_sous.Name = "rb_sous";
            this.rb_sous.Size = new System.Drawing.Size(124, 24);
            this.rb_sous.TabIndex = 1;
            this.rb_sous.TabStop = true;
            this.rb_sous.Text = "Soustraction";
            this.rb_sous.UseVisualStyleBackColor = true;
            // 
            // rb_add
            // 
            this.rb_add.AutoSize = true;
            this.rb_add.Location = new System.Drawing.Point(24, 45);
            this.rb_add.Name = "rb_add";
            this.rb_add.Size = new System.Drawing.Size(92, 24);
            this.rb_add.TabIndex = 0;
            this.rb_add.TabStop = true;
            this.rb_add.Text = "Addition";
            this.rb_add.UseVisualStyleBackColor = true;
            // 
            // Calculer
            // 
            this.Calculer.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Calculer.Location = new System.Drawing.Point(525, 274);
            this.Calculer.Name = "Calculer";
            this.Calculer.Size = new System.Drawing.Size(108, 34);
            this.Calculer.TabIndex = 7;
            this.Calculer.Text = "Calculer";
            this.Calculer.UseVisualStyleBackColor = false;
            this.Calculer.Click += new System.EventHandler(this.Calculer_Click);
            // 
            // Quitter
            // 
            this.Quitter.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Quitter.Location = new System.Drawing.Point(525, 344);
            this.Quitter.Name = "Quitter";
            this.Quitter.Size = new System.Drawing.Size(108, 28);
            this.Quitter.TabIndex = 8;
            this.Quitter.Text = "Quitter";
            this.Quitter.UseVisualStyleBackColor = false;
            this.Quitter.Click += new System.EventHandler(this.Quitter_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(352, 421);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(166, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "©Copyright LWK-2026";
            // 
            // Calculatrice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(906, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Quitter);
            this.Controls.Add(this.Calculer);
            this.Controls.Add(this.OperationBox);
            this.Controls.Add(this.txt_resultat);
            this.Controls.Add(this.txt_nbr2);
            this.Controls.Add(this.txt_nbr1);
            this.Controls.Add(this.resultat);
            this.Controls.Add(this.Nbr2);
            this.Controls.Add(this.Nbr1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Calculatrice";
            this.Text = "Calculatrice";
            this.OperationBox.ResumeLayout(false);
            this.OperationBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Nbr1;
        private System.Windows.Forms.Label Nbr2;
        private System.Windows.Forms.Label resultat;
        private System.Windows.Forms.TextBox txt_nbr1;
        private System.Windows.Forms.TextBox txt_nbr2;
        private System.Windows.Forms.TextBox txt_resultat;
        private System.Windows.Forms.GroupBox OperationBox;
        private System.Windows.Forms.RadioButton rb_div;
        private System.Windows.Forms.RadioButton rb_mu;
        private System.Windows.Forms.RadioButton rb_sous;
        private System.Windows.Forms.RadioButton rb_add;
        private System.Windows.Forms.Button Calculer;
        private System.Windows.Forms.Button Quitter;
        private System.Windows.Forms.Label label1;
    }
}

