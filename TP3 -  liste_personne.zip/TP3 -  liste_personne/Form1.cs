﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.LinkLabel;

namespace TP3____liste_personne
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_effacer_Click(object sender, EventArgs e)
        {
            textBoxcin.Text = " ";
            textBoxnom.Text = " ";
            textBoxprenom.Text = " ";
            textBoxanniv.Text = " ";
            rbsituation.Checked = false;
            Cbciv.SelectedIndex = 1;
            Pbimage.Image = null;
        }

        private void Pbimage_Click(object sender, EventArgs e)
        {
            openFileDialog1.Multiselect = false;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Pbimage.Image = new Bitmap(openFileDialog1.FileName);
            }
        }

        private bool CodeExiste()
        {
            bool exists = false;
            if (dataGridView1.Rows.Count > 0)
            {
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    if (dataGridView1.Rows[i].Cells[0].Value.ToString() == textBoxcin.Text)
                    {
                        exists = true; break;
                    }
                }
            }
            return exists;
        }
            


private void btn_recherche_Click(object sender, EventArgs e)
        {
            string cin = textBoxcin.Text;
            
            if (CodeExiste())
            {
                MessageBox.Show("CIN existe déja", "Information");
            }
            else
            {
                MessageBox.Show("CIN n'existe pas encore", "Information");
            }

        }

        private void btn_ajout_Click(object sender, EventArgs e)
        {
            if (!CodeExiste())
            {
                dataGridView1.Rows.Add(textBoxcin.Text, Pbimage.Image, textBoxnom.Text, textBoxprenom.Text, textBoxanniv.Text, Cbciv.SelectedItem, rbsituation.Checked);
            }
            else
            {
                MessageBox.Show("CIN existe déja", "Information");
            }
        }

        private void btn_vider_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
        }

        private void btn_tri_Click(object sender, EventArgs e)
        {
            int col = dataGridView1.CurrentCell.ColumnIndex;
            dataGridView1.Sort(dataGridView1.Columns[col], ListSortDirection.Ascending);
        }

        private void btn_suppr_Click(object sender, EventArgs e)
        {
            int ligne = dataGridView1.CurrentCell.ColumnIndex;
            dataGridView1.Rows.RemoveAt(ligne);
        }

        private void btn_expo_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Title = "Fichier csv";
            saveFileDialog1.Filter = " Csv Files | *.csv";
            saveFileDialog1.DefaultExt = "csv";
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                String[] lignes = new string[dataGridView1.Rows.Count];
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                    {
                            lignes[i] += dataGridView1.Rows[i].Cells[j].Value.ToString() + ";";
                    }
                }
                System.IO.File.WriteAllLines(saveFileDialog1.FileName, lignes);
            }
        }
        int ligne = -1;
        private void btn_modif_Click(object sender, EventArgs e)
        {
            if (ligne == -1)
            {   
                ligne = dataGridView1.CurrentCell.ColumnIndex;
                //recuperation des informations
                textBoxcin.Text = dataGridView1.Rows[ligne].Cells[0].Value.ToString();
                Pbimage.Image = (Image) dataGridView1.Rows[ligne].Cells[1].Value;
                textBoxnom.Text = dataGridView1.Rows[ligne].Cells[2].Value.ToString();
                textBoxprenom.Text = dataGridView1.Rows[ligne].Cells[3].Value.ToString();
                textBoxanniv.Text = dataGridView1.Rows[ligne].Cells[4].Value.ToString();
                Cbciv.SelectedItem = dataGridView1.Rows[ligne].Cells[5].Value.ToString();
                rbsituation.Checked = (bool) dataGridView1.Rows[ligne].Cells[6].Value;
                //désactiver les buttons
                btn_ajout.Enabled = false;
                btn_effacer.Enabled = false;
                btn_recherche.Enabled = false;
                btn_modif.Text = "valider";
            }
            else
            {
                //modification des informations
                dataGridView1.Rows[ligne].Cells[0].Value = textBoxcin.Text;
                dataGridView1.Rows[ligne].Cells[1].Value = Pbimage.Image;
                dataGridView1.Rows[ligne].Cells[2].Value = textBoxnom.Text ;
                dataGridView1.Rows[ligne].Cells[3].Value = textBoxprenom.Text ;
                dataGridView1.Rows[ligne].Cells[4].Value = textBoxanniv.Text ;
                dataGridView1.Rows[ligne].Cells[5].Value = Cbciv.SelectedItem;
                dataGridView1.Rows[ligne].Cells[6].Value = rbsituation.Checked;
            //désactiver les buttons
            btn_ajout.Enabled = false;
                btn_effacer.Enabled = false;
                btn_recherche.Enabled = false;
                btn_modif.Text = "Modifier";
            }    
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
