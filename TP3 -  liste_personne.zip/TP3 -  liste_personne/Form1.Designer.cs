﻿namespace TP3____liste_personne
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Pbimage = new System.Windows.Forms.PictureBox();
            this.labcin = new System.Windows.Forms.Label();
            this.labnom = new System.Windows.Forms.Label();
            this.labanniv = new System.Windows.Forms.Label();
            this.labsituation = new System.Windows.Forms.Label();
            this.labPrenom = new System.Windows.Forms.Label();
            this.labciv = new System.Windows.Forms.Label();
            this.textBoxcin = new System.Windows.Forms.TextBox();
            this.textBoxnom = new System.Windows.Forms.TextBox();
            this.textBoxanniv = new System.Windows.Forms.TextBox();
            this.textBoxprenom = new System.Windows.Forms.TextBox();
            this.rbsituation = new System.Windows.Forms.RadioButton();
            this.Cbciv = new System.Windows.Forms.ComboBox();
            this.btn_recherche = new System.Windows.Forms.Button();
            this.btn_ajout = new System.Windows.Forms.Button();
            this.btn_effacer = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btn_modif = new System.Windows.Forms.Button();
            this.btn_suppr = new System.Windows.Forms.Button();
            this.btn_tri = new System.Windows.Forms.Button();
            this.btn_vider = new System.Windows.Forms.Button();
            this.btn_expo = new System.Windows.Forms.Button();
            this.CIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Image = new System.Windows.Forms.DataGridViewImageColumn();
            this.Nom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Prenom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Dtdenais = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Civilite = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Marie = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Pbimage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // Pbimage
            // 
            this.Pbimage.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Pbimage.Location = new System.Drawing.Point(28, 12);
            this.Pbimage.Name = "Pbimage";
            this.Pbimage.Size = new System.Drawing.Size(177, 188);
            this.Pbimage.TabIndex = 0;
            this.Pbimage.TabStop = false;
            this.Pbimage.Click += new System.EventHandler(this.Pbimage_Click);
            // 
            // labcin
            // 
            this.labcin.AutoSize = true;
            this.labcin.Location = new System.Drawing.Point(265, 37);
            this.labcin.Name = "labcin";
            this.labcin.Size = new System.Drawing.Size(36, 20);
            this.labcin.TabIndex = 1;
            this.labcin.Text = "CIN";
            // 
            // labnom
            // 
            this.labnom.AutoSize = true;
            this.labnom.Location = new System.Drawing.Point(265, 94);
            this.labnom.Name = "labnom";
            this.labnom.Size = new System.Drawing.Size(42, 20);
            this.labnom.TabIndex = 2;
            this.labnom.Text = "Nom";
            // 
            // labanniv
            // 
            this.labanniv.AutoSize = true;
            this.labanniv.Location = new System.Drawing.Point(265, 155);
            this.labanniv.Name = "labanniv";
            this.labanniv.Size = new System.Drawing.Size(142, 20);
            this.labanniv.TabIndex = 3;
            this.labanniv.Text = "Date de naissance";
            // 
            // labsituation
            // 
            this.labsituation.AutoSize = true;
            this.labsituation.Location = new System.Drawing.Point(265, 212);
            this.labsituation.Name = "labsituation";
            this.labsituation.Size = new System.Drawing.Size(72, 20);
            this.labsituation.TabIndex = 4;
            this.labsituation.Text = "Situation";
            // 
            // labPrenom
            // 
            this.labPrenom.AutoSize = true;
            this.labPrenom.Location = new System.Drawing.Point(769, 94);
            this.labPrenom.Name = "labPrenom";
            this.labPrenom.Size = new System.Drawing.Size(72, 20);
            this.labPrenom.TabIndex = 5;
            this.labPrenom.Text = "Prénoms";
            // 
            // labciv
            // 
            this.labciv.AutoSize = true;
            this.labciv.Location = new System.Drawing.Point(769, 155);
            this.labciv.Name = "labciv";
            this.labciv.Size = new System.Drawing.Size(53, 20);
            this.labciv.TabIndex = 6;
            this.labciv.Text = "Civilité";
            // 
            // textBoxcin
            // 
            this.textBoxcin.Location = new System.Drawing.Point(418, 37);
            this.textBoxcin.Name = "textBoxcin";
            this.textBoxcin.Size = new System.Drawing.Size(272, 26);
            this.textBoxcin.TabIndex = 7;
            // 
            // textBoxnom
            // 
            this.textBoxnom.Location = new System.Drawing.Point(418, 94);
            this.textBoxnom.Name = "textBoxnom";
            this.textBoxnom.Size = new System.Drawing.Size(272, 26);
            this.textBoxnom.TabIndex = 8;
            // 
            // textBoxanniv
            // 
            this.textBoxanniv.Location = new System.Drawing.Point(418, 149);
            this.textBoxanniv.Name = "textBoxanniv";
            this.textBoxanniv.Size = new System.Drawing.Size(272, 26);
            this.textBoxanniv.TabIndex = 9;
            this.textBoxanniv.Text = "             /            /   ";
            // 
            // textBoxprenom
            // 
            this.textBoxprenom.Location = new System.Drawing.Point(874, 88);
            this.textBoxprenom.Name = "textBoxprenom";
            this.textBoxprenom.Size = new System.Drawing.Size(275, 26);
            this.textBoxprenom.TabIndex = 11;
            // 
            // rbsituation
            // 
            this.rbsituation.AutoSize = true;
            this.rbsituation.Location = new System.Drawing.Point(431, 225);
            this.rbsituation.Name = "rbsituation";
            this.rbsituation.Size = new System.Drawing.Size(96, 24);
            this.rbsituation.TabIndex = 13;
            this.rbsituation.TabStop = true;
            this.rbsituation.Text = "Marié (e)";
            this.rbsituation.UseVisualStyleBackColor = true;
            // 
            // Cbciv
            // 
            this.Cbciv.FormattingEnabled = true;
            this.Cbciv.Items.AddRange(new object[] {
            "",
            "Monsieur ",
            "Madame",
            "Mademoiselle"});
            this.Cbciv.Location = new System.Drawing.Point(874, 149);
            this.Cbciv.Name = "Cbciv";
            this.Cbciv.Size = new System.Drawing.Size(275, 28);
            this.Cbciv.TabIndex = 14;
            // 
            // btn_recherche
            // 
            this.btn_recherche.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btn_recherche.Location = new System.Drawing.Point(475, 262);
            this.btn_recherche.Name = "btn_recherche";
            this.btn_recherche.Size = new System.Drawing.Size(155, 40);
            this.btn_recherche.TabIndex = 15;
            this.btn_recherche.Text = "Rechercher";
            this.btn_recherche.UseVisualStyleBackColor = false;
            this.btn_recherche.Click += new System.EventHandler(this.btn_recherche_Click);
            // 
            // btn_ajout
            // 
            this.btn_ajout.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btn_ajout.Location = new System.Drawing.Point(654, 262);
            this.btn_ajout.Name = "btn_ajout";
            this.btn_ajout.Size = new System.Drawing.Size(168, 40);
            this.btn_ajout.TabIndex = 16;
            this.btn_ajout.Text = "Ajouter";
            this.btn_ajout.UseVisualStyleBackColor = false;
            this.btn_ajout.Click += new System.EventHandler(this.btn_ajout_Click);
            // 
            // btn_effacer
            // 
            this.btn_effacer.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btn_effacer.Location = new System.Drawing.Point(843, 262);
            this.btn_effacer.Name = "btn_effacer";
            this.btn_effacer.Size = new System.Drawing.Size(160, 40);
            this.btn_effacer.TabIndex = 17;
            this.btn_effacer.Text = "Effacer";
            this.btn_effacer.UseVisualStyleBackColor = false;
            this.btn_effacer.Click += new System.EventHandler(this.btn_effacer_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CIN,
            this.Image,
            this.Nom,
            this.Prenom,
            this.Dtdenais,
            this.Civilite,
            this.Marie});
            this.dataGridView1.Location = new System.Drawing.Point(28, 328);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(1072, 203);
            this.dataGridView1.TabIndex = 18;
            // 
            // btn_modif
            // 
            this.btn_modif.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btn_modif.Location = new System.Drawing.Point(92, 552);
            this.btn_modif.Name = "btn_modif";
            this.btn_modif.Size = new System.Drawing.Size(113, 36);
            this.btn_modif.TabIndex = 19;
            this.btn_modif.Text = "Modifier";
            this.btn_modif.UseVisualStyleBackColor = false;
            this.btn_modif.Click += new System.EventHandler(this.btn_modif_Click);
            // 
            // btn_suppr
            // 
            this.btn_suppr.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btn_suppr.Location = new System.Drawing.Point(283, 552);
            this.btn_suppr.Name = "btn_suppr";
            this.btn_suppr.Size = new System.Drawing.Size(138, 36);
            this.btn_suppr.TabIndex = 20;
            this.btn_suppr.Text = "Supprimer";
            this.btn_suppr.UseVisualStyleBackColor = false;
            this.btn_suppr.Click += new System.EventHandler(this.btn_suppr_Click);
            // 
            // btn_tri
            // 
            this.btn_tri.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btn_tri.Location = new System.Drawing.Point(504, 552);
            this.btn_tri.Name = "btn_tri";
            this.btn_tri.Size = new System.Drawing.Size(113, 36);
            this.btn_tri.TabIndex = 21;
            this.btn_tri.Text = "Trier";
            this.btn_tri.UseVisualStyleBackColor = false;
            this.btn_tri.Click += new System.EventHandler(this.btn_tri_Click);
            // 
            // btn_vider
            // 
            this.btn_vider.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btn_vider.Location = new System.Drawing.Point(697, 552);
            this.btn_vider.Name = "btn_vider";
            this.btn_vider.Size = new System.Drawing.Size(144, 36);
            this.btn_vider.TabIndex = 22;
            this.btn_vider.Text = "Vider";
            this.btn_vider.UseVisualStyleBackColor = false;
            this.btn_vider.Click += new System.EventHandler(this.btn_vider_Click);
            // 
            // btn_expo
            // 
            this.btn_expo.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btn_expo.Location = new System.Drawing.Point(924, 552);
            this.btn_expo.Name = "btn_expo";
            this.btn_expo.Size = new System.Drawing.Size(146, 36);
            this.btn_expo.TabIndex = 23;
            this.btn_expo.Text = "Exporter CSV";
            this.btn_expo.UseVisualStyleBackColor = false;
            this.btn_expo.Click += new System.EventHandler(this.btn_expo_Click);
            // 
            // CIN
            // 
            this.CIN.HeaderText = "CIN";
            this.CIN.MinimumWidth = 8;
            this.CIN.Name = "CIN";
            this.CIN.ReadOnly = true;
            this.CIN.Width = 150;
            // 
            // Image
            // 
            this.Image.HeaderText = "Image";
            this.Image.MinimumWidth = 8;
            this.Image.Name = "Image";
            this.Image.ReadOnly = true;
            this.Image.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Image.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Image.Width = 150;
            // 
            // Nom
            // 
            this.Nom.HeaderText = "Nom";
            this.Nom.MinimumWidth = 8;
            this.Nom.Name = "Nom";
            this.Nom.ReadOnly = true;
            this.Nom.Width = 150;
            // 
            // Prenom
            // 
            this.Prenom.HeaderText = "Prénom";
            this.Prenom.MinimumWidth = 8;
            this.Prenom.Name = "Prenom";
            this.Prenom.ReadOnly = true;
            this.Prenom.Width = 150;
            // 
            // Dtdenais
            // 
            this.Dtdenais.HeaderText = "Date de naissance";
            this.Dtdenais.MinimumWidth = 8;
            this.Dtdenais.Name = "Dtdenais";
            this.Dtdenais.ReadOnly = true;
            this.Dtdenais.Width = 150;
            // 
            // Civilite
            // 
            this.Civilite.HeaderText = "Civilité";
            this.Civilite.MinimumWidth = 8;
            this.Civilite.Name = "Civilite";
            this.Civilite.ReadOnly = true;
            this.Civilite.Width = 150;
            // 
            // Marie
            // 
            this.Marie.HeaderText = "Marié (e)";
            this.Marie.MinimumWidth = 8;
            this.Marie.Name = "Marie";
            this.Marie.ReadOnly = true;
            this.Marie.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Marie.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Marie.Width = 150;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(546, 591);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(166, 20);
            this.label1.TabIndex = 24;
            this.label1.Text = "©Copyright LWK-2026";
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(1096, 586);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(122, 31);
            this.button1.TabIndex = 25;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1230, 621);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_expo);
            this.Controls.Add(this.btn_vider);
            this.Controls.Add(this.btn_tri);
            this.Controls.Add(this.btn_suppr);
            this.Controls.Add(this.btn_modif);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btn_effacer);
            this.Controls.Add(this.btn_ajout);
            this.Controls.Add(this.btn_recherche);
            this.Controls.Add(this.Cbciv);
            this.Controls.Add(this.rbsituation);
            this.Controls.Add(this.textBoxprenom);
            this.Controls.Add(this.textBoxanniv);
            this.Controls.Add(this.textBoxnom);
            this.Controls.Add(this.textBoxcin);
            this.Controls.Add(this.labciv);
            this.Controls.Add(this.labPrenom);
            this.Controls.Add(this.labsituation);
            this.Controls.Add(this.labanniv);
            this.Controls.Add(this.labnom);
            this.Controls.Add(this.labcin);
            this.Controls.Add(this.Pbimage);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Personne";
            ((System.ComponentModel.ISupportInitialize)(this.Pbimage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Pbimage;
        private System.Windows.Forms.Label labcin;
        private System.Windows.Forms.Label labnom;
        private System.Windows.Forms.Label labanniv;
        private System.Windows.Forms.Label labsituation;
        private System.Windows.Forms.Label labPrenom;
        private System.Windows.Forms.Label labciv;
        private System.Windows.Forms.TextBox textBoxcin;
        private System.Windows.Forms.TextBox textBoxnom;
        private System.Windows.Forms.TextBox textBoxanniv;
        private System.Windows.Forms.TextBox textBoxprenom;
        private System.Windows.Forms.RadioButton rbsituation;
        private System.Windows.Forms.ComboBox Cbciv;
        private System.Windows.Forms.Button btn_recherche;
        private System.Windows.Forms.Button btn_ajout;
        private System.Windows.Forms.Button btn_effacer;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btn_modif;
        private System.Windows.Forms.Button btn_suppr;
        private System.Windows.Forms.Button btn_tri;
        private System.Windows.Forms.Button btn_vider;
        private System.Windows.Forms.Button btn_expo;
        private System.Windows.Forms.DataGridViewTextBoxColumn CIN;
        private System.Windows.Forms.DataGridViewImageColumn Image;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nom;
        private System.Windows.Forms.DataGridViewTextBoxColumn Prenom;
        private System.Windows.Forms.DataGridViewTextBoxColumn Dtdenais;
        private System.Windows.Forms.DataGridViewTextBoxColumn Civilite;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Marie;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}

