﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BasicCalculator
{

    /// <summary>
    /// A basic Calculator
    /// </summary>
    public partial class Calculator : Form
    {
        #region Constructor

        /// <summary>
        /// Defaut constructor
        /// </summary>
        public Calculator()
        {
            InitializeComponent();
        }

        #endregion

        #region Clear

        /// <summary>
        /// Clear the user input text
        /// </summary>
        /// <param name="sender">The event sender.</param>
        /// <param name="e">The event arguments.</param>
        private void CEButton_Click(object sender, EventArgs e)
        {
            // Clear the text from the user input test Box
            this.UserInputText.Text = string.Empty;

            // Focus the user input text 
            FocusInputText();
        }

        private void DelButton_Click(object sender, EventArgs e)
        {
            DeleteTextValue();

            // Focus the user input text 
            FocusInputText();

        }
        #endregion

 #region operating functions
        private void PerButton_Click(object sender, EventArgs e)
        {
            InsertTextValue("/");

            // Focus the user input text 
            FocusInputText();
        }

        private void MultiButton_Click(object sender, EventArgs e)
        {
            InsertTextValue("*");

            // Focus the user input text 
            FocusInputText();
        }

        private void MinusButton_Click(object sender, EventArgs e)
        {
            InsertTextValue("-");

            // Focus the user input text 
            FocusInputText();
        }

        private void PlusButton_Click(object sender, EventArgs e)
        {
            InsertTextValue("+");

            // Focus the user input text 
            FocusInputText();
        }

        private void EqualButton_Click(object sender, EventArgs e)
        {
            Calculatorequal();

            // Focus the user input text 
            FocusInputText();
        }
        #endregion

        #region number
        private void NineButton_Click(object sender, EventArgs e)
        {
            InsertTextValue("9");
        }

        private void EightButton_Click(object sender, EventArgs e)
        {
            InsertTextValue("8");
        }

        private void SevenButton_Click(object sender, EventArgs e)
        {
            InsertTextValue("7");
        }

        private void SixButton_Click(object sender, EventArgs e)
        {
            InsertTextValue("6");
        }

        private void FiveButton_Click(object sender, EventArgs e)
        {
            InsertTextValue("5");
        }
        private void FourButton_Click(object sender, EventArgs e)
        {
            InsertTextValue("4");
        }

     
        private void ThreeButton_Click(object sender, EventArgs e)
        {
            InsertTextValue("3");
        }

        private void TwoButton_Click(object sender, EventArgs e)
        {
            InsertTextValue("2");
        }

        private void OneButton_Click(object sender, EventArgs e)
        {
            InsertTextValue("1");
        }

        private void ZeroButton_Click(object sender, EventArgs e)
        {
            InsertTextValue("0");
        }

       

        private void DotButton_Click(object sender, EventArgs e)
        {
            InsertTextValue(".");
        }

        #endregion

        /// <summary>
        /// Calculates the given equation and outputs the answers to the user label
        /// </summary>
        private void Calculatorequal()
        {
            // Focus the user input text 
            FocusInputText();
        }

        #region Private Helpers

        /// <summary>
        ///  Focuses the user input text
        /// </summary>
        private void FocusInputText()
        {
            this.UserInputText.Focus();
            
        }
        /// <summary>
        /// Insert the given text into the user input text Box 
        /// </summary>

        private void InsertTextValue(string value)
        {
            // Remember selection start
            var selectionStart = this.UserInputText.SelectionStart;

            // Set new test 
            this.UserInputText.Text = this.UserInputText.Text.Insert(this.UserInputText.SelectionStart, value);
        
            // Restore the selection start 
            this.UserInputText.SelectionStart = selectionStart + value.Length;

            // Set selection length to zero
            this.UserInputText.SelectionLength = 0;
        
        }

        /// <summary>
        /// Delete the character to right of the selection start of user input text box 
        /// </summary>

        private void DeleteTextValue()
        {
            //If we don't have a value to delete return
            if (this.UserInputText.Text.Length >= this.UserInputText.SelectionStart + 1)
                return;

            // Remember selection start
            var selectionStart = this.UserInputText.SelectionStart;

            // Set new test 
            this.UserInputText.Text = this.UserInputText.Text.Remove(this.UserInputText.SelectionStart, 1);

            // Restore the selection start 
            this.UserInputText.SelectionStart = selectionStart ;

            // Set selection length to zero
            this.UserInputText.SelectionLength = 0;

        }


        #endregion


    }

}
