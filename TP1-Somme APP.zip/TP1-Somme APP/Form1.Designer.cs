﻿namespace TP1_Somme_APP
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.labnb1 = new System.Windows.Forms.Label();
            this.labnb2 = new System.Windows.Forms.Label();
            this.labres = new System.Windows.Forms.Label();
            this.textres = new System.Windows.Forms.TextBox();
            this.textnb2 = new System.Windows.Forms.TextBox();
            this.btn_calculer = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textnb1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // labnb1
            // 
            this.labnb1.AutoSize = true;
            this.labnb1.Location = new System.Drawing.Point(79, 45);
            this.labnb1.Name = "labnb1";
            this.labnb1.Size = new System.Drawing.Size(78, 20);
            this.labnb1.TabIndex = 0;
            this.labnb1.Text = "Nombre 1";
            // 
            // labnb2
            // 
            this.labnb2.AutoSize = true;
            this.labnb2.Location = new System.Drawing.Point(79, 123);
            this.labnb2.Name = "labnb2";
            this.labnb2.Size = new System.Drawing.Size(78, 20);
            this.labnb2.TabIndex = 1;
            this.labnb2.Text = "Nombre 2";
            // 
            // labres
            // 
            this.labres.AutoSize = true;
            this.labres.Location = new System.Drawing.Point(79, 188);
            this.labres.Name = "labres";
            this.labres.Size = new System.Drawing.Size(69, 20);
            this.labres.TabIndex = 2;
            this.labres.Text = "Resultat";
            // 
            // textres
            // 
            this.textres.Location = new System.Drawing.Point(238, 188);
            this.textres.Name = "textres";
            this.textres.ReadOnly = true;
            this.textres.Size = new System.Drawing.Size(268, 26);
            this.textres.TabIndex = 4;
            this.textres.Text = "0";
            // 
            // textnb2
            // 
            this.textnb2.Location = new System.Drawing.Point(238, 123);
            this.textnb2.Name = "textnb2";
            this.textnb2.Size = new System.Drawing.Size(268, 26);
            this.textnb2.TabIndex = 5;
            this.textnb2.Text = "0";
            // 
            // btn_calculer
            // 
            this.btn_calculer.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btn_calculer.Location = new System.Drawing.Point(278, 256);
            this.btn_calculer.Name = "btn_calculer";
            this.btn_calculer.Size = new System.Drawing.Size(121, 42);
            this.btn_calculer.TabIndex = 6;
            this.btn_calculer.Text = "Calculer";
            this.btn_calculer.UseVisualStyleBackColor = false;
            this.btn_calculer.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button2.Location = new System.Drawing.Point(457, 256);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(110, 42);
            this.button2.TabIndex = 7;
            this.button2.Text = "Supprimer";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textnb1
            // 
            this.textnb1.Location = new System.Drawing.Point(238, 45);
            this.textnb1.Name = "textnb1";
            this.textnb1.Size = new System.Drawing.Size(268, 26);
            this.textnb1.TabIndex = 8;
            this.textnb1.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textnb1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btn_calculer);
            this.Controls.Add(this.textnb2);
            this.Controls.Add(this.textres);
            this.Controls.Add(this.labres);
            this.Controls.Add(this.labnb2);
            this.Controls.Add(this.labnb1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Somme";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labnb1;
        private System.Windows.Forms.Label labnb2;
        private System.Windows.Forms.Label labres;
        private System.Windows.Forms.TextBox textres;
        private System.Windows.Forms.TextBox textnb2;
        private System.Windows.Forms.Button btn_calculer;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textnb1;
    }
}

