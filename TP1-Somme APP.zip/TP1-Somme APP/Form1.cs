﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1_Somme_APP
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int nbr1 = int.Parse(textnb1.Text);
            int nbr2 = int.Parse(textnb2.Text);
            int somme = nbr1 + nbr2;
            textres.Text = somme.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textnb1.Clear();
            textnb2.Clear();
            textres.Clear();
            MessageBox.Show("Supprimer!!", "Information");
        }
    }
}
